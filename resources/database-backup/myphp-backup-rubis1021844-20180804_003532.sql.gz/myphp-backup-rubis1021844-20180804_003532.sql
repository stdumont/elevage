CREATE DATABASE IF NOT EXISTS `rubis1021844`;

USE `rubis1021844`;

DROP TABLE IF EXISTS `agenda`;

CREATE TABLE `agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `allDay` tinyint(1) NOT NULL DEFAULT '0',
  `start` varchar(255) NOT NULL,
  `end` varchar(255) DEFAULT NULL,
  `generated` tinyint(1) NOT NULL DEFAULT '0',
  `editable` tinyint(1) DEFAULT '0',
  `color` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `chiens`;

CREATE TABLE `chiens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `affixe` varchar(255) DEFAULT NULL,
  `sexe` varchar(1) NOT NULL,
  `race_id` int(11) NOT NULL,
  `robe_id` int(11) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `date_deces` date DEFAULT NULL,
  `pere_id` int(11) DEFAULT NULL,
  `mere_id` int(11) DEFAULT NULL,
  `puce` varchar(255) DEFAULT NULL,
  `passeport` varchar(255) DEFAULT NULL,
  `pedigree` varchar(255) DEFAULT NULL,
  `tatouage` varchar(255) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `portee_id` int(11) DEFAULT NULL,
  `chiot_id` int(11) DEFAULT NULL,
  `present` tinyint(1) NOT NULL DEFAULT '0',
  `produit` tinyint(1) NOT NULL DEFAULT '0',
  `reproducteur` tinyint(1) NOT NULL DEFAULT '0',
  `remarques` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chien_race_idx` (`race_id`),
  KEY `fk_chien_robe_idx` (`robe_id`),
  KEY `fk_chien_pere_idx` (`pere_id`),
  KEY `fk_chien_mere_idx` (`mere_id`),
  KEY `fk_chien_client_idx` (`client_id`),
  KEY `fk_chien_portee_idx` (`portee_id`),
  KEY `idx_chien_nom` (`nom`),
  KEY `idx_chien_sexe` (`sexe`),
  KEY `fk_chien_chiot_idx` (`chiot_id`),
  CONSTRAINT `fk_chien_chiot` FOREIGN KEY (`chiot_id`) REFERENCES `chiots` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_chien_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_chien_mere` FOREIGN KEY (`mere_id`) REFERENCES `chiens` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_chien_pere` FOREIGN KEY (`pere_id`) REFERENCES `chiens` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_chien_portee` FOREIGN KEY (`portee_id`) REFERENCES `portees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_chien_race` FOREIGN KEY (`race_id`) REFERENCES `races` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_chien_robe` FOREIGN KEY (`robe_id`) REFERENCES `robes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `chiots`;

CREATE TABLE `chiots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portee_id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `sexe` varchar(1) NOT NULL,
  `robe_id` int(11) NOT NULL,
  `chien_id` int(11) DEFAULT NULL,
  `remarques` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiot_portee_idx` (`portee_id`),
  KEY `fk_chiot_robe_idx` (`robe_id`),
  KEY `fk_chiot_chien_idx` (`chien_id`),
  CONSTRAINT `fk_chiot_chien` FOREIGN KEY (`chien_id`) REFERENCES `chiens` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_chiot_portee` FOREIGN KEY (`portee_id`) REFERENCES `portees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_chiot_robe` FOREIGN KEY (`robe_id`) REFERENCES `robes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `rue` varchar(255) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `code_postal` varchar(5) DEFAULT NULL,
  `localite` varchar(255) DEFAULT NULL,
  `pays` varchar(255) DEFAULT NULL,
  `tel1` varchar(255) DEFAULT NULL,
  `tel2` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `remarques` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `clients` VALUES("1","Dumont-Delange","Stéphane-Catherine","Rue Favauche","1","5150","Floriffoux","Belgique","081/44.68.68",NULL,"info@lesrubis.com",NULL,"2018-08-03 22:06:45","2018-08-03 22:07:43");
INSERT INTO `clients` VALUES("2","Paurin","Jeannette","Rue St-Germain","167/D","4861","Soiron","Belgique","087/46.10.12",NULL,NULL,NULL,"2018-08-03 22:09:56","2018-08-03 22:09:56");
INSERT INTO `clients` VALUES("3","Dohet","Serge","Quai Mativa","37/23","4020","Liège","Belgique","04/342.72.65","0474/80.71.02",NULL,NULL,"2018-08-03 22:11:42","2018-08-03 22:11:42");
INSERT INTO `clients` VALUES("4","De Pauw","Sébastien","Faubourg de Bruxelles","89/12","6041","Gosselies","Belgique","0468/53.08.16",NULL,NULL,NULL,"2018-08-03 22:13:06","2018-08-03 22:13:06");
INSERT INTO `clients` VALUES("5","Scrufari","Chlöe","Place Deflinne","7","7600","Peruwelz","Belgique","0492/98.62.67",NULL,NULL,NULL,"2018-08-03 22:14:30","2018-08-03 22:14:30");
INSERT INTO `clients` VALUES("6","Doumont","Bernadette","Tienne Calbalasse","23","5020","Malonne","Belgique","0478/27.00.09",NULL,NULL,NULL,"2018-08-03 22:15:17","2018-08-03 22:15:17");
INSERT INTO `clients` VALUES("7","Cremer","Alice","Rechter Strassens","82","4770","Born (Amel)","Belgique","080/34.99.64",NULL,NULL,NULL,"2018-08-03 22:16:24","2018-08-03 22:16:24");
INSERT INTO `clients` VALUES("8","Nasri","Aline","Bey de Foer","8","1370","Jodoigne","Belgique","0497/55.40.06",NULL,NULL,NULL,"2018-08-03 22:17:13","2018-08-03 22:17:13");
INSERT INTO `clients` VALUES("9","Mayeux","Kim","Av. de Drummonville","7","1420","Braine-l-Alleud","Belgique","0473/31.68.88",NULL,NULL,"Prénom réel Fabienne (pour recommandé)","2018-08-03 22:18:27","2018-08-03 22:18:59");
INSERT INTO `clients` VALUES("10","Montalbetti","Florence","Rue de la Station","16","1320","Bauvechain","Belgique","010/86.19.02",NULL,NULL,NULL,"2018-08-03 22:21:08","2018-08-03 22:21:08");
INSERT INTO `clients` VALUES("11","Delbouille","Audrey","Rue des Colombières","13/26","4100","Seraing","Belgique","0470/26.89.63",NULL,NULL,NULL,"2018-08-03 22:22:15","2018-08-03 22:22:15");
INSERT INTO `clients` VALUES("12","Guiducci","Pascal","Av. Wanderpepen","84/16","7130","Binche","Belgique","064/33.95.79","0478/36.04.52",NULL,NULL,"2018-08-03 22:23:41","2018-08-03 22:23:41");
INSERT INTO `clients` VALUES("13","Godfrind","Michaël","Marvie","54","6600","Bastogne","Belgique","061/21.75.98","0496/60.63.19",NULL,NULL,"2018-08-03 22:24:57","2018-08-03 22:24:57");



DROP TABLE IF EXISTS `documents`;

CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typedoc_id` int(11) NOT NULL,
  `chien_id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `date_document` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_document_typedoc_idx` (`typedoc_id`),
  KEY `fk_document_chien_idx` (`chien_id`),
  CONSTRAINT `fk_document_chien` FOREIGN KEY (`chien_id`) REFERENCES `chiens` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_document_typedoc` FOREIGN KEY (`typedoc_id`) REFERENCES `typedocs` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `elevages`;

CREATE TABLE `elevages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `affixe` varchar(255) DEFAULT NULL,
  `responsable` varchar(255) DEFAULT NULL,
  `rue` varchar(255) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `code_postal` varchar(5) DEFAULT NULL,
  `localite` varchar(255) DEFAULT NULL,
  `pays` varchar(255) DEFAULT NULL,
  `tva` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `elevages` VALUES("1","Elevage canin des Rubis de Lady C","des Rubis de Lady C","Stéphane-Catherine Dumont-Delange","Rue Favauche","1","5150","Floriffoux","Belgique","BE 0690.365.232","+32 81 44 68 68","info@lesrubis.com",NULL,"2018-08-03 22:03:03");



DROP TABLE IF EXISTS `fichiers`;

CREATE TABLE `fichiers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `nomFichier` varchar(255) NOT NULL,
  `contentType` varchar(255) NOT NULL,
  `taille` int(11) NOT NULL,
  `donnee` mediumblob NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_fichier_document_idx` (`document_id`),
  CONSTRAINT `fk_fichier_document` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `mouvements`;

CREATE TABLE `mouvements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typeMvt` varchar(45) NOT NULL,
  `motifMvt` varchar(45) NOT NULL,
  `dateMvt` date NOT NULL,
  `chien_id` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Mvt_chien_fk_idx` (`chien_id`),
  CONSTRAINT `fk_mouvements_chien` FOREIGN KEY (`chien_id`) REFERENCES `chiens` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `parameters`;

CREATE TABLE `parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `valeur` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `parameters` VALUES("1","APP_NAME","Elevage canin",NULL,NULL);
INSERT INTO `parameters` VALUES("2","APP_VERSION","0.1",NULL,NULL);
INSERT INTO `parameters` VALUES("3","APP_CREATION_YEAR","2018",NULL,NULL);
INSERT INTO `parameters` VALUES("4","APP_AUTHOR","Stéphane Dumont",NULL,NULL);
INSERT INTO `parameters` VALUES("5","APP_AUTHOR_MAIL","dumont.stephane@gmail.com",NULL,NULL);



DROP TABLE IF EXISTS `portees`;

CREATE TABLE `portees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `pere_id` int(11) NOT NULL,
  `mere_id` int(11) NOT NULL,
  `race_id` int(11) NOT NULL,
  `date_saillie_1` date DEFAULT NULL,
  `date_saillie_2` date DEFAULT NULL,
  `date_naissance` date NOT NULL,
  `remarques` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_portee_pere_idx` (`pere_id`),
  KEY `fk_portee_mere_idx` (`mere_id`),
  KEY `fk_portee_race_idx` (`race_id`),
  CONSTRAINT `fk_portee_mere` FOREIGN KEY (`mere_id`) REFERENCES `chiens` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_portee_pere` FOREIGN KEY (`pere_id`) REFERENCES `chiens` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_portee_race` FOREIGN KEY (`race_id`) REFERENCES `races` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `races`;

CREATE TABLE `races` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `races` VALUES("1","Cavalier King Charles",NULL,NULL);
INSERT INTO `races` VALUES("2","Chihuahua",NULL,NULL);



DROP TABLE IF EXISTS `robes`;

CREATE TABLE `robes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `race_id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_robe_race_idx` (`race_id`),
  CONSTRAINT `fk_robe_race` FOREIGN KEY (`race_id`) REFERENCES `races` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `robes` VALUES("1","1","Blenheïm",NULL,NULL);
INSERT INTO `robes` VALUES("2","1","Tricolore",NULL,NULL);
INSERT INTO `robes` VALUES("3","1","Noir-Feu",NULL,NULL);
INSERT INTO `robes` VALUES("4","1","Rubis",NULL,NULL);



DROP TABLE IF EXISTS `typedocs`;

CREATE TABLE `typedocs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `typedocs` VALUES("1","Pedigree","2018-08-01 21:00:56","2018-08-01 21:03:43");
INSERT INTO `typedocs` VALUES("2","Contrat de vente","2018-08-01 21:02:22","2018-08-01 21:02:22");
INSERT INTO `typedocs` VALUES("3","Fiche ADN","2018-08-01 21:25:46","2018-08-01 21:25:46");
INSERT INTO `typedocs` VALUES("4","Déclaration de saillie et de naissance","2018-08-01 21:26:42","2018-08-01 21:29:57");
INSERT INTO `typedocs` VALUES("5","Carte DogId","2018-08-01 21:27:07","2018-08-01 21:27:07");
INSERT INTO `typedocs` VALUES("6","Résultat d\'expo","2018-08-01 21:27:47","2018-08-01 21:27:47");
INSERT INTO `typedocs` VALUES("7","Contrat de cession définitive","2018-08-01 21:29:15","2018-08-01 21:29:15");
INSERT INTO `typedocs` VALUES("8","Photo","2018-08-01 21:29:35","2018-08-01 21:29:35");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isAdmin` varchar(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `users` VALUES("1","Stéphane","dumont.stephane@gmail.com","$2y$10$EunfkQSE6wjJkG4WIUi7Xejyzq8U8eaorBZ.cGFhUN2yCAH2dVn1m","1",NULL,NULL);
INSERT INTO `users` VALUES("2","Catherine","catherine.delange@skynet.be","$2y$10$jX9w0MXYHBbcex6VMkSMhOMVQ6iNQ2c5MLZdjUyrRBUZoDc66aEO2","0",NULL,NULL);
